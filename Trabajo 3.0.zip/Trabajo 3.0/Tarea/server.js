// Tarea/server.js
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const db = require('./models'); // Importa la inicialización de la DB

dotenv.config();

const userRoutes = require('./routes/userRoutes');
const taskRoutes = require('./routes/taskRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); // Habilita CORS
app.use(express.json()); // Habilita el body parser para JSON

// Rutas
app.use('/api/users', userRoutes);
app.use('/api/tasks', taskRoutes);

// Ruta de prueba
app.get('/', (req, res) => {
  res.send('API de TareasApp funcionando!');
});

// Servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
  console.log(`Accede a http://localhost:${PORT}`);
});

// La sincronización de la DB se maneja en 'models/index.js'