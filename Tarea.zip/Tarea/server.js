// Tarea/server.js - CÓDIGO FINAL PORTABLE
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

// 1. DEFINICIÓN DE RUTA BASE AL INICIO (Para portabilidad)
global.__basedir = __dirname; 

// 2. IMPORTAR DB DESPUÉS DE DEFINIR __basedir
const db = require('./models'); 

dotenv.config();

const userRoutes = require('./routes/userRoutes');
const taskRoutes = require('./routes/taskRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); 
app.use(express.json());

// Rutas
app.use('/api/users', userRoutes);
app.use('/api/tasks', taskRoutes);

// Ruta de prueba
app.get('/', (req, res) => {
  res.send('API de TareasApp funcionando!');
});

// Servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
  console.log(`Accede a http://localhost:${PORT}`);
});