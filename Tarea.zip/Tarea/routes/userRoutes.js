// Tarea/routes/userRoutes.js
const express = require('express');
const { registerUser, loginUser, getProfile } = require('../controllers/userController');
const protect = require('../middleware/auth');

const router = express.Router();

// Rutas públicas
router.post('/register', registerUser);
router.post('/login', loginUser);

// Ruta privada
router.get('/profile', protect, getProfile);

module.exports = router;