// Tarea/controllers/streakController.js - CÓDIGO FINAL
const db = require('../models');
const { Op } = require('sequelize');

// GET /api/tasks/streak
exports.getStreak = async (req, res) => {
    try {
        const streakInfo = await db.Streak.findOne({
            where: { userId: req.user.id },
        });

        if (!streakInfo) {
            return res.json({ daysConsecutive: 0, lastActivityDate: null, message: "Racha no iniciada." });
        }

        res.json({
            daysConsecutive: streakInfo.daysConsecutive,
            lastActivityDate: streakInfo.lastActivityDate,
        });

    } catch (error) {
        console.error("Error al obtener racha:", error);
        res.status(500).json({ message: 'Error interno al consultar la racha.' });
    }
};

// GET /api/tasks/achievements
exports.getAchievements = async (req, res) => {
    try {
        const achievements = await req.user.getAchievements({
            attributes: ['type', 'description', 'target'],
            joinTableAttributes: ['createdAt'], 
        });

        res.json(achievements);

    } catch (error) {
        console.error("Error al obtener logros:", error);
        res.status(500).json({ message: 'Error interno al consultar logros.' });
    }
};

// --- LÓGICA DE NEGOCIO ---
exports.checkAndAward = async (userId) => {
    try {
        const user = await db.User.findByPk(userId);
        if (!user) return;

        // 1. Lógica de Tareas Completadas (Logro)
        const totalCompleted = await db.Task.count({
            where: { userId: userId, completed: true }
        });

        const availableAchievements = await db.Achievement.findAll({
            where: { type: ['PrimerTarea', 'DiezTareas'] }
        });

        for (const achievement of availableAchievements) {
            if (totalCompleted >= achievement.target) {
                const hasAchievement = await user.hasAchievement(achievement);
                if (!hasAchievement) {
                    await user.addAchievement(achievement);
                    console.log(`Usuario ${userId} ganó el logro: ${achievement.type}`);
                }
            }
        }

        // 2. Lógica de Racha
        let streak = await db.Streak.findOrCreate({
            where: { userId: userId },
            defaults: { userId: userId, daysConsecutive: 0, lastActivityDate: null },
        });
        streak = streak[0];
        
        const today = new Date().toISOString().split('T')[0];
        const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
        
        let shouldUpdateStreak = false;

        if (!streak.lastActivityDate) {
            streak.daysConsecutive = 1;
            shouldUpdateStreak = true;
        } else if (streak.lastActivityDate < yesterday) {
            streak.daysConsecutive = 1;
            shouldUpdateStreak = true;
        } else if (streak.lastActivityDate === yesterday) {
            streak.daysConsecutive += 1;
            shouldUpdateStreak = true;
        }

        if (shouldUpdateStreak) {
            streak.lastActivityDate = today;
            if (streak.daysConsecutive === 1) streak.startDate = today;
            await streak.save();
        }

        // 3. Logro de Racha (Ej: 7 días)
        const streakAchievement = await db.Achievement.findOne({ where: { type: 'Racha7Dias' } });
        if (streakAchievement && streak.daysConsecutive >= streakAchievement.target) {
            const hasStreakAchievement = await user.hasAchievement(streakAchievement);
            if (!hasStreakAchievement) {
                 await user.addAchievement(streakAchievement);
                 console.log(`Usuario ${userId} ganó el logro: ${streakAchievement.type}`);
            }
        }


    } catch (error) {
        console.error("Error en la lógica de logros/racha:", error);
    }
};