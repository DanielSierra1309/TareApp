// Tarea/controllers/taskController.js - CÓDIGO COMPLETO FINAL
const db = require('../models');
const Task = db.Task;
const { Op } = require('sequelize');
// Importar la lógica de racha/logros
const { checkAndAward } = require('./streakController'); 

// GET /api/tasks (Obtener todas las tareas del usuario)
exports.getTasks = async (req, res) => {
    try {
        const tasks = await Task.findAll({
            where: { 
                userId: req.user.id,
                // Opcional: solo tareas NO completadas para la vista principal
                completed: false 
            },
            order: [['dueDate', 'ASC']]
        });
        res.json(tasks);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener las tareas' });
    }
};

// GET /api/tasks/completed (Obtener tareas completadas)
exports.getCompletedTasks = async (req, res) => {
    try {
        const tasks = await Task.findAll({
            where: { 
                userId: req.user.id,
                completed: true 
            },
            order: [['completedAt', 'DESC']]
        });
        res.json(tasks);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener las tareas completadas' });
    }
};


// POST /api/tasks (Crear una nueva tarea)
exports.createTask = async (req, res) => {
    const { title, description, tag, dueDate } = req.body;

    if (!title) {
        return res.status(400).json({ message: 'El título es obligatorio' });
    }

    try {
        const task = await Task.create({
            title,
            description,
            tag,
            dueDate,
            userId: req.user.id,
        });
        res.status(201).json(task);
    } catch (error) {
        res.status(500).json({ message: 'Error al crear la tarea' });
    }
};


// PUT /api/tasks/:id (Actualizar una tarea)
exports.updateTask = async (req, res) => {
    const taskId = req.params.id;
    const { title, description, tag, dueDate, completed } = req.body;

    try {
        const task = await Task.findOne({
            where: { id: taskId, userId: req.user.id },
        });

        if (!task) {
            return res.status(404).json({ message: 'Tarea no encontrada o no pertenece al usuario' });
        }

        let completedAt = task.completedAt;
        
        // LÓGICA DE RACHA/LOGROS: Si el estado de 'completed' cambió de false a true
        if (completed === true && task.completed === false) {
            completedAt = new Date();
            // LLAMADA A LA LÓGICA DE LOGROS/RACHA
            await checkAndAward(req.user.id); 
        } else if (completed === false && task.completed === true) {
            // Si se desmarca, quitamos la fecha de completado
            completedAt = null;
        }

        const updatedTask = await task.update({
            title: title ?? task.title,
            description: description ?? task.description,
            tag: tag ?? task.tag,
            dueDate: dueDate ?? task.dueDate,
            completed: completed !== undefined ? completed : task.completed,
            completedAt: completedAt,
        });
        
        res.json(updatedTask);
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar la tarea' });
    }
};


// DELETE /api/tasks/:id (Eliminar una tarea)
exports.deleteTask = async (req, res) => {
    const taskId = req.params.id;
    try {
        const result = await Task.destroy({
            where: { id: taskId, userId: req.user.id },
        });

        if (result === 0) {
            return res.status(404).json({ message: 'Tarea no encontrada o no pertenece al usuario' });
        }
        
        res.status(204).send(); // 204 No Content

    } catch (error) {
        res.status(500).json({ message: 'Error al eliminar la tarea' });
    }
};