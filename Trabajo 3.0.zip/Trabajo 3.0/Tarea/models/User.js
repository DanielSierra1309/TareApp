// Tarea/models/User.js
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true, 
    },
    password: {
      type: DataTypes.STRING, 
      allowNull: false,
    },
    achievements: {
      type: DataTypes.TEXT, // Almacenará JSON string
      defaultValue: '[]',
    },
    streak: {
      type: DataTypes.INTEGER, 
      defaultValue: 0,
    },
    lastActive: {
      type: DataTypes.DATE, 
      allowNull: true,
    },
  }, {
    timestamps: true, 
  });

  return User;
};