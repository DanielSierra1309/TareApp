// Tarea/models/Streak.js
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Streak = sequelize.define('Streak', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    daysConsecutive: { // Corresponde a 'dias_consecutivos' 
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    startDate: { // Corresponde a 'fecha_inicio' 
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    lastActivityDate: { // Para validar si la racha se rompe
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    // userId se establecerá por la relación
  }, {
    timestamps: true,
    tableName: 'Racha', // Consistente con el MER 
  });

  // Asegura que cada usuario tenga una sola fila de racha
  Streak.belongsTo(sequelize.models.User, {
    foreignKey: 'userId',
    unique: true,
  });

  return Streak;
};