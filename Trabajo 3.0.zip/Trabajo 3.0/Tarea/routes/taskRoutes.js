// Tarea/routes/taskRoutes.js
const express = require('express');
const {
  getTasks,
  createTask,
  updateTask,
  deleteTask,
  getCompletedTasks
} = require('../controllers/taskController');
const { getStreak, getAchievements } = require('../controllers/streakController'); // NUEVO
const protect = require('../middleware/auth');

const router = express.Router();

// Aplica el middleware 'protect' a todas las rutas de tareas
router.use(protect);

router.route('/')
  .get(getTasks) // GET /api/tasks
  .post(createTask); // POST /api/tasks

// --- NUEVAS RUTAS DE ESTADÍSTICAS (requeridas en el documento ) ---
router.route('/achievements')
  .get(getAchievements); // GET /api/tasks/achievements (o si prefieres /api/achievements)

router.route('/streak')
  .get(getStreak); // GET /api/tasks/streak (o si prefieres /api/streak)

// --------------------------------------------------------------------------

router.route('/completed')
  .get(getCompletedTasks); // GET /api/tasks/completed

router.route('/:id')
  .put(updateTask) // PUT /api/tasks/:id
  .delete(deleteTask); // DELETE /api/tasks/:id

module.exports = router;