// Tarea/routes/taskRoutes.js - CÓDIGO FINAL
const express = require('express');
const {
  getTasks,
  createTask,
  updateTask,
  deleteTask,
  getCompletedTasks // <--- ¡Ahora estas son funciones reales!
} = require('../controllers/taskController');
// ... [Resto del archivo] ...
const { getStreak, getAchievements } = require('../controllers/streakController'); 
const protect = require('../middleware/auth');

const router = express.Router();

// Aplica el middleware 'protect' a todas las rutas de tareas
router.use(protect);

router.route('/')
  .get(getTasks)
  .post(createTask);

router.route('/achievements')
  .get(getAchievements); 

router.route('/streak')
  .get(getStreak); 

router.route('/completed')
  .get(getCompletedTasks); 

router.route('/:id')
  .put(updateTask)
  .delete(deleteTask);

module.exports = router;