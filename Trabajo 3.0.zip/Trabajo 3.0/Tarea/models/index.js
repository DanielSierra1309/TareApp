// Tarea/models/index.js
const { Sequelize } = require('sequelize');
const dotenv = require('dotenv');

dotenv.config();

// Inicializar Sequelize y conectar a SQLite
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite',
  logging: false,
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// --- 1. Importar nuevos modelos ---
db.User = require('./User')(sequelize, Sequelize);
db.Task = require('./Task')(sequelize, Sequelize);
db.Achievement = require('./Achievement')(sequelize, Sequelize); // NUEVO
db.Streak = require('./Streak')(sequelize, Sequelize);           // NUEVO

// --- 2. Definir Relaciones (ya existentes) ---
db.User.hasMany(db.Task, { foreignKey: 'userId', as: 'tasks' });
db.Task.belongsTo(db.User, { foreignKey: 'userId', as: 'user' });

// --- 3. Definir Nuevas Relaciones ---

// Racha (1:1 con Usuario)
db.User.hasOne(db.Streak, { foreignKey: 'userId', as: 'streakInfo' }); // Un usuario tiene una racha
db.Streak.belongsTo(db.User, { foreignKey: 'userId', as: 'user' });    // Una racha pertenece a un usuario

// Logro (N:M - Muchos a Muchos) usando una tabla intermedia
db.User.belongsToMany(db.Achievement, {
  through: 'Usuario_Logro', // Nombre de la tabla intermedia (MER )
  as: 'achievements',
  foreignKey: 'userId',
});

db.Achievement.belongsToMany(db.User, {
  through: 'Usuario_Logro',
  as: 'users',
  foreignKey: 'logroId',
});
// ---------------------------------

// Sincronizar la base de datos
db.sequelize.sync({ alter: true }) // 'alter: true' actualizará el esquema
  .then(() => {
    console.log('Base de datos sincronizada.');
    // Inicializar los logros disponibles (solo la primera vez)
    return require('./seedAchievements')(db);
  })
  .catch((err) => {
    console.error('Error al sincronizar la base de datos:', err);
  });

module.exports = db;