// Tarea/models/Streak.js
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Streak = sequelize.define('Streak', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    daysConsecutive: { 
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    startDate: { 
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    lastActivityDate: { 
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
  }, {
    timestamps: true,
    tableName: 'Racha',
  });

  Streak.belongsTo(sequelize.models.User, {
    foreignKey: 'userId',
    unique: true,
  });

  return Streak;
};