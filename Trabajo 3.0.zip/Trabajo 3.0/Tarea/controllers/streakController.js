// Tarea/controllers/streakController.js
const db = require('../models');
const { Op } = require('sequelize');

// GET /api/streak
exports.getStreak = async (req, res) => {
    try {
        const streakInfo = await db.Streak.findOne({
            where: { userId: req.user.id },
        });

        if (!streakInfo) {
            return res.json({ daysConsecutive: 0, lastActivityDate: null, message: "Racha no iniciada." });
        }

        res.json({
            daysConsecutive: streakInfo.daysConsecutive,
            lastActivityDate: streakInfo.lastActivityDate,
        });

    } catch (error) {
        console.error("Error al obtener racha:", error);
        res.status(500).json({ message: 'Error interno al consultar la racha.' });
    }
};

// GET /api/achievements
exports.getAchievements = async (req, res) => {
    try {
        // Obtenemos los logros que el usuario ha desbloqueado a través de la tabla intermedia
        const achievements = await req.user.getAchievements({
            attributes: ['type', 'description', 'target'],
            joinTableAttributes: ['createdAt'], // Para saber cuándo lo ganó
        });

        res.json(achievements);

    } catch (error) {
        console.error("Error al obtener logros:", error);
        res.status(500).json({ message: 'Error interno al consultar logros.' });
    }
};

// --- LÓGICA DE NEGOCIO ---
// Esta función se llamará desde taskController cuando una tarea se complete.
exports.checkAndAward = async (userId) => {
    try {
        const user = await db.User.findByPk(userId);
        if (!user) return;

        // 1. Lógica de Tareas Completadas (Logro)
        const totalCompleted = await db.Task.count({
            where: { userId: userId, completed: true }
        });

        const availableAchievements = await db.Achievement.findAll({
            where: { type: ['PrimerTarea', 'DiezTareas'] }
        });

        for (const achievement of availableAchievements) {
            if (totalCompleted >= achievement.target) {
                // Añadir logro solo si no lo tiene
                const hasAchievement = await user.hasAchievement(achievement);
                if (!hasAchievement) {
                    await user.addAchievement(achievement);
                    console.log(`Usuario ${userId} ganó el logro: ${achievement.type}`);
                }
            }
        }

        // 2. Lógica de Racha
        let streak = await db.Streak.findOrCreate({
            where: { userId: userId },
            defaults: { userId: userId, daysConsecutive: 0, lastActivityDate: null },
        });
        streak = streak[0];
        
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
        const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
        
        let shouldUpdateStreak = false;

        if (!streak.lastActivityDate) {
            // Primera tarea completada
            streak.daysConsecutive = 1;
            shouldUpdateStreak = true;
        } else if (streak.lastActivityDate < yesterday) {
            // Racha rota (última actividad fue antes de ayer)
            streak.daysConsecutive = 1; // Reinicia la racha
            shouldUpdateStreak = true;
        } else if (streak.lastActivityDate === yesterday) {
            // Racha mantenida (completó algo ayer y hoy)
            streak.daysConsecutive += 1;
            shouldUpdateStreak = true;
        }

        if (shouldUpdateStreak) {
            streak.lastActivityDate = today;
            if (streak.daysConsecutive === 1) streak.startDate = today;
            await streak.save();
        }

        // 3. Logro de Racha (Ej: 7 días)
        const streakAchievement = await db.Achievement.findOne({ where: { type: 'Racha7Dias' } });
        if (streakAchievement && streak.daysConsecutive >= streakAchievement.target) {
            const hasStreakAchievement = await user.hasAchievement(streakAchievement);
            if (!hasStreakAchievement) {
                 await user.addAchievement(streakAchievement);
                 console.log(`Usuario ${userId} ganó el logro: ${streakAchievement.type}`);
            }
        }


    } catch (error) {
        console.error("Error en la lógica de logros/racha:", error);
    }
};