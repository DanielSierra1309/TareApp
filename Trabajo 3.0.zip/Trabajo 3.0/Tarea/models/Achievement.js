// Tarea/models/Achievement.js
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Achievement = sequelize.define('Achievement', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    type: { // Ej: 'TareasCompletadas', 'RachaLarga'
      type: DataTypes.STRING,
      allowNull: false,
      unique: true, // Asumimos que los tipos de logros son únicos
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    target: { // El valor necesario para desbloquear (ej: 10, 30, 7)
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  }, {
    timestamps: false,
    tableName: 'Logro', // Consistente con el MER 
  });

  return Achievement;
};