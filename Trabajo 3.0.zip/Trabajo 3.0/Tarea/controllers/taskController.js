// Tarea/controllers/taskController.js
const db = require('../models');
const Task = db.Task;
// Importar la nueva lógica
const { checkAndAward } = require('./streakController'); // NUEVO

// ... [Otras funciones getTasks, createTask, deleteTask, getCompletedTasks] ...

// PUT /api/tasks/:id (Actualizar una tarea)
exports.updateTask = async (req, res) => {
  // ... [Código anterior de obtención de tarea] ...
  const taskId = req.params.id;
  const { title, description, tag, dueDate, completed } = req.body;

  try {
    const task = await Task.findOne({
      where: { id: taskId, userId: req.user.id },
    });

    if (!task) {
      return res.status(404).json({ message: 'Tarea no encontrada o no pertenece al usuario' });
    }

    let completedAt = task.completedAt;
    // Si el estado de 'completed' ha cambiado de falso a verdadero
    if (completed === true && task.completed === false) {
        completedAt = new Date();
        // LLAMADA A LA LÓGICA DE LOGROS/RACHA
        await checkAndAward(req.user.id); 
    } else if (completed === false && task.completed === true) {
        // Si se desmarca, quitamos la fecha de completado
        completedAt = null;
    }

    const updatedTask = await task.update({
      title: title ?? task.title,
      description: description ?? task.description,
      tag: tag ?? task.tag,
      dueDate: dueDate ?? task.dueDate,
      completed: completed !== undefined ? completed : task.completed,
      completedAt: completedAt,
    });
    
    res.json(updatedTask);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar la tarea' });
  }
};